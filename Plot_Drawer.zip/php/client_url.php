<?php

class client_url
{
  public $url_1 = "http://localhost:1200";
}